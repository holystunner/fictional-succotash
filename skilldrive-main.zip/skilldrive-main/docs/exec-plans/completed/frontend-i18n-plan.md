# Frontend I18n Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Establish a maintainable frontend i18n layer and migrate the first shared and user-facing surfaces onto it.

**Architecture:** Resolve locale once in the root layout, expose the locale and dictionary through a provider, and consume domain-scoped translations from shared UI and selected pages.

**Tech Stack:** Next.js 14 App Router, React 18, TypeScript, Vitest, Testing Library

---

### Task 1: Add i18n infrastructure

**Files:**
- Create: `frontend/src/i18n/config.ts`
- Create: `frontend/src/i18n/get-dictionary.ts`
- Create: `frontend/src/i18n/i18n-provider.tsx`
- Create: `frontend/src/i18n/use-i18n.ts`
- Create: `frontend/src/i18n/messages/en-US.ts`
- Create: `frontend/src/i18n/messages/zh-CN.ts`

- [x] Define supported locales, default fallback behavior, and request locale resolution helpers.
- [x] Add typed dictionaries with domain sections for metadata, navigation, shell, login, and dashboard.
- [x] Expose locale and dictionary through a React provider plus a hook with safe defaults.

### Task 2: Connect the root layout

**Files:**
- Modify: `frontend/src/app/layout.tsx`

- [x] Resolve locale from the incoming request at layout time.
- [x] Generate localized metadata from the selected dictionary.
- [x] Wrap the app with the new i18n provider and set `<html lang>` from the resolved locale.

### Task 3: Migrate shared shell and navigation

**Files:**
- Modify: `frontend/src/lib/navigation.ts`
- Modify: `frontend/src/components/app/app-shell.tsx`
- Modify: `frontend/src/components/app/workspace-boundary-note.tsx`

- [x] Move shared navigation labels into dictionaries.
- [x] Update the app shell to read translated chrome labels from the i18n hook.
- [x] Update workspace boundary messaging to use translated content.

### Task 4: Migrate the first feature pages

**Files:**
- Modify: `frontend/src/app/login/page.tsx`
- Modify: `frontend/src/app/dashboard/page.tsx`

- [x] Replace hardcoded login copy with dictionary-driven content.
- [x] Replace hardcoded dashboard copy with dictionary-driven content.
- [x] Keep runtime capability branches intact while moving only presentation strings.

### Task 5: Verify behavior

**Files:**
- Modify: `frontend/src/__tests__/pages.test.tsx`
- Modify: `frontend/src/__tests__/app-shell-auth.test.tsx`

- [x] Update assertions that depend on migrated copy or shared navigation labels.
- [x] Run targeted frontend tests for the affected pages and shell.
- [x] Run lint or type-aware verification if the local toolchain allows it within reasonable time.
